# Entrega Prototipo 3 — CollaBoard (Equipo 1e)

Paquete organizado con toda la documentación, diagramas actualizados (`correciones-proxy-y-edge`: 17 contenedores, 8 redes, `reverse-proxy` separado de `gateway` y `pixels-ui` en `app`), estudios de rendimiento, evidencia de seguridad y scripts ejecutables para la sustentación del Prototipo 3.

## Estructura de carpetas

```text
Entrega-P3-CollaBoard/
├── 01-documento-principal/
│   ├── p3_1e_actualizado.pdf              # Informe P3 completo y actualizado (sin encabezados de navegador)
│   ├── p3_1e_actualizado.md               # Fuente Markdown del informe P3
│   ├── GUIA-SUSTENTACION-P3.pdf           # Guion y guía paso a paso para la sustentación oral y en vivo
│   └── GUIA-SUSTENTACION-P3.md            # Fuente Markdown de la guía de sustentación
├── 02-diagramas-arquitectura/
│   ├── drawio/                            # Fuentes editables Draw.io actualizados a correciones-proxy-y-edge
│   │   ├── vista-despliegue.P3.drawio
│   │   └── vista-capas.P3.drawio
│   └── png/                               # Vistas exportadas en alta resolución
│       ├── 01-vista-cc.P3.png             # Vista de Componentes y Conectores
│       ├── 02-vista-despliegue.P3.png     # Vista de Despliegue (17 contenedores, 8 redes)
│       ├── 03-vista-capas.P3.png          # Vista de Capas (5 tiers)
│       └── 04-vista-descomposicion.P3.png # Vista de Descomposición
├── 03-rendimiento/
│   ├── 01-boards-rest-3000vus/            # Estudio GET /api/boards (1..3.000 VUs, rodilla y quiebre)
│   ├── 02-pizarra-websocket/              # Estudio WebSocket pizarra-api (1..200 VUs + control multisala)
│   ├── 03-pixels-websocket/               # Estudio WebSocket pixels-api (hasta 1.500 VUs)
│   └── 04-tls-y-segmentacion-http/        # Costo TLS 1.3 + segmentación de red S3
├── 04-evidencia-seguridad/
│   ├── S1-tls/                            # Captura Wireshark antes/después (TLS 1.3)
│   └── S3-segmentacion/                   # Matriz 144 celdas y Wireshark S3
└── 05-pruebas-en-vivo/                    # Scripts PowerShell + k6 para ejecutar durante la sustentación
```

## Notas rápidas para la sustentación
- Los scripts en vivo también permanecen en la raíz del repositorio (`Pruebas en vivo/`) listos para ejecutarse directamente contra el stack Docker activo.
- Los PDFs principales (`p3_1e_actualizado.pdf` y `GUIA-SUSTENTACION-P3.pdf`) están en `01-documento-principal/` y duplicados en la raíz del repositorio para acceso inmediato.
